from django.apps import AppConfig


class PointventeConfig(AppConfig):
    name = 'pointvente'
    # def ready(self):
    #     from jobs import updater
    #     updater.start()
