from django.apps import AppConfig


class GestionstockConfig(AppConfig):
    name = 'gestionstock'
